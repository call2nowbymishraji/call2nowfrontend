const PromoSlide = require('../models/PromoSlide');

exports.publicSlides = async (req, res) => {
  const slides = await PromoSlide.find({ active: true }).sort({ order: 1, createdAt: -1 }).populate('profile', 'shopName pageSlug');
  res.json({ slides });
};
