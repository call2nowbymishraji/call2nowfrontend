const router = require('express').Router();
const c = require('../controllers/adminController');
const { protect, adminOnly } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.use(protect, adminOnly);

router.get('/profiles', c.listProfiles);
router.put('/profiles/:id/tenure', c.setTenure);
router.delete('/profiles/:id', c.deleteProfile);
router.delete('/profiles/:id/products/:productId', c.removeProduct);
router.get('/slides', c.listSlides);
router.post('/slides', upload.single('image'), c.createSlide);
router.put('/slides/:id', c.updateSlide);
router.delete('/slides/:id', c.deleteSlide);

module.exports = router;
