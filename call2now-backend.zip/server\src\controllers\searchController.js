const BusinessProfile = require('../models/BusinessProfile');

const escapeRegex = (s = '') => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const promoActive = {
  'promo.days': { $gt: 0 },
  'promo.startDate': { $gte: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000) },
};

exports.search = async (req, res) => {
  try {
    const { q, category, location } = req.query;
    const filter = { status: 'active' };
    if (category) filter.category = new RegExp(`^${escapeRegex(category)}$`, 'i');
    if (location) filter.address = new RegExp(escapeRegex(location), 'i');
    if (q) {
      const rx = new RegExp(escapeRegex(q), 'i');
      filter.$or = [
        { shopName: rx },
        { ownerName: rx },
        { description: rx },
        { category: rx },
        { customCategory: rx },
        { 'products.name': rx },
        { 'products.description': rx },
      ];
    }
    const profiles = await BusinessProfile.find(filter).sort({ createdAt: -1 }).limit(100);
    profiles.sort((a, b) => promoScore(b) - promoScore(a));
    res.json({ profiles });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
};

exports.suggested = async (req, res) => {
  try {
    const promoted = await BusinessProfile.find({ status: 'active', ...promoActive }).sort({ 'promo.startDate': -1 }).limit(8);
    let profiles = promoted;
    if (profiles.length < 8) {
      const ids = new Set(promoted.map((p) => String(p._id)));
      const rest = await BusinessProfile.find({ status: 'active', _id: { $nin: [...ids] } })
        .sort({ createdAt: -1 })
        .limit(8 - profiles.length);
      profiles = profiles.concat(rest);
    }
    res.json({ profiles });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
};

function promoScore(p) {
  const active = p.promo?.days > 0 && p.promo?.startDate && new Date(p.promo.startDate) > new Date(Date.now() - 60 * 24 * 60 * 60 * 1000);
  return active ? p.promo.days : 0;
}
