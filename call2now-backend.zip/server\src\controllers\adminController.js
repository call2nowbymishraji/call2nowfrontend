const BusinessProfile = require('../models/BusinessProfile');
const PromoSlide = require('../models/PromoSlide');
const { storeFile } = require('../utils/files');

exports.listProfiles = async (req, res) => {
  const profiles = await BusinessProfile.find().sort({ createdAt: -1 }).populate('user', 'name email');
  res.json({ profiles: profiles.map((p) => ({ ...p.toObject(), email: p.user?.email || p.email })) });
};

exports.setTenure = async (req, res) => {
  const days = Number(req.body.days);
  if (![0, 30, 60].includes(days)) return res.status(400).json({ message: 'Tenure must be 0, 30 or 60 days' });
  const profile = await BusinessProfile.findById(req.params.id);
  if (!profile) return res.status(404).json({ message: 'Profile not found' });
  profile.promo = { days, startDate: days > 0 ? new Date() : null };
  await profile.save();
  res.json({ message: `Promotion set to ${days} days`, profile });
};

exports.deleteProfile = async (req, res) => {
  const profile = await BusinessProfile.findByIdAndDelete(req.params.id);
  if (!profile) return res.status(404).json({ message: 'Profile not found' });
  res.json({ message: 'Profile deleted' });
};

exports.removeProduct = async (req, res) => {
  const profile = await BusinessProfile.findById(req.params.id);
  if (!profile) return res.status(404).json({ message: 'Profile not found' });
  const before = profile.products.length;
  profile.products = profile.products.filter((p) => String(p._id) !== req.params.productId);
  if (profile.products.length === before) return res.status(404).json({ message: 'Product not found' });
  if (profile.products.length === 0) return res.status(400).json({ message: 'A profile must keep at least 1 product' });
  await profile.save();
  res.json({ message: 'Product removed', profile });
};

exports.listSlides = async (req, res) => {
  const slides = await PromoSlide.find().sort({ order: 1, createdAt: -1 }).populate('profile', 'shopName pageSlug');
  res.json({ slides });
};

exports.createSlide = async (req, res) => {
  const { title, subtitle, profileId, customUrl } = req.body;
  if (!title?.trim()) return res.status(400).json({ message: 'Slide title is required' });
  const image = await storeFile(req.file, 'slides');
  const slide = await PromoSlide.create({ title, subtitle: subtitle || '', image, profile: profileId || null, customUrl: customUrl || '' });
  res.status(201).json({ message: 'Slide created', slide });
};

exports.updateSlide = async (req, res) => {
  const slide = await PromoSlide.findByIdAndUpdate(req.params.id, { $set: req.body }, { new: true });
  if (!slide) return res.status(404).json({ message: 'Slide not found' });
  res.json({ message: 'Slide updated', slide });
};

exports.deleteSlide = async (req, res) => {
  const slide = await PromoSlide.findByIdAndDelete(req.params.id);
  if (!slide) return res.status(404).json({ message: 'Slide not found' });
  res.json({ message: 'Slide deleted' });
};
