const router = require('express').Router();
const c = require('../controllers/promoController');

router.get('/slides', c.publicSlides);

module.exports = router;
